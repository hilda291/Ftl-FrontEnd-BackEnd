package com.example.ftl_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FtlProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FtlProjectApplication.class, args);
	}

}
