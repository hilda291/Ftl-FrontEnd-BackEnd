package com.example.batchChunk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatchChunkApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchChunkApplication.class, args);
	}

}
